import Table from "./components/table/table";
import "./index.css";


export function App() {
    return (
    <>
        <Table />
    </>
    )
};

export default App;